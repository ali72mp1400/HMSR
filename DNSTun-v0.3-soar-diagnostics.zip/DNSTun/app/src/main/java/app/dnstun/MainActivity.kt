package app.dnstun

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var screens: List<View>
    private var tab = 0

    private lateinit var tvChip: TextView
    private lateinit var tvTimer: TextView
    private lateinit var tvDown: TextView
    private lateinit var tvUp: TextView
    private lateinit var tvTotal: TextView
    private lateinit var btnConnect: FrameLayout
    private lateinit var orb: OrbView
    private lateinit var tvOrbState: TextView
    private lateinit var tvOrbSub: TextView
    private lateinit var tileProfile: LinearLayout
    private lateinit var tvProfileName: TextView
    private lateinit var tileResolvers: LinearLayout
    private lateinit var tvResCount: TextView
    private lateinit var btnLog: TextView
    private lateinit var tvHint: TextView

    private lateinit var btnBackP: ImageView
    private lateinit var btnAddP: TextView
    private lateinit var listProfiles: LinearLayout
    private lateinit var etExtra: EditText

    private lateinit var btnBackR: ImageView
    private lateinit var tvResInfo: TextView
    private lateinit var btnScan: TextView
    private lateinit var btnSaveRes: TextView
    private lateinit var btnDefaultRes: TextView
    private lateinit var tvScan: TextView
    private lateinit var etResolvers: EditText

    private var scanning = false
    private var scanEngine: Engine? = null
    private var connectedAt = 0L

    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L
    private var baseRx = 0L
    private var baseTx = 0L

    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            if (DnsVpnService.state != DnsVpnService.STATE_CONNECTED) return
            if (connectedAt > 0) {
                val s = (System.currentTimeMillis() - connectedAt) / 1000
                tvTimer.text = String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
            }
            sampleTraffic()
            handler.postDelayed(this, 1000)
        }
    }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) startVpn() else toast("مجوز VPN رد شد")
    }

    private val notificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val i = intent ?: return
            val s = i.getStringExtra(DnsVpnService.EXTRA_STATE) ?: return
            applyState(s, i.getStringExtra(DnsVpnService.EXTRA_MESSAGE) ?: "")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        setContentView(R.layout.activity_main)
        bindViews()
        styleViews()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        Store.ensureDefaults(this)
        etExtra.setText(Store.prefs(this).getString("extra", ""))
        showTab(0)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (tab != 0) {
                    leaveTab()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        tileProfile.setOnClickListener { renderProfiles(); showTab(1) }
        tileResolvers.setOnClickListener { loadResolverEditor(); showTab(2) }
        btnBackP.setOnClickListener { leaveTab() }
        btnBackR.setOnClickListener { leaveTab() }
        btnAddP.setOnClickListener { addProfileDialog() }
        btnLog.setOnClickListener { showLog() }
        btnSaveRes.setOnClickListener { saveResolverEditor(); toast("ذخیره شد") }
        btnDefaultRes.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("بازگشت به لیست پیش‌فرض؟")
                .setMessage("لیست فعلی و نتیجه‌ی اسکن پاک میشه.")
                .setPositiveButton("بله") { _, _ ->
                    Store.loadDefaultResolvers(this)
                    Store.validFile(this).delete()
                    loadResolverEditor()
                    updateHome()
                }
                .setNegativeButton("لغو", null)
                .show()
        }
        btnScan.setOnClickListener { toggleScan() }

        btnConnect.setOnClickListener {
            val s = DnsVpnService.state
            if (s == DnsVpnService.STATE_CONNECTED || s == DnsVpnService.STATE_CONNECTING) stopVpn()
            else prepareVpn()
        }
    }

    private fun bindViews() {
        screens = listOf<View>(
            findViewById(R.id.screenHome),
            findViewById(R.id.screenProfiles),
            findViewById(R.id.screenResolvers)
        )
        tvChip = findViewById(R.id.tvChip)
        tvTimer = findViewById(R.id.tvTimer)
        tvDown = findViewById(R.id.tvDown)
        tvUp = findViewById(R.id.tvUp)
        tvTotal = findViewById(R.id.tvTotal)
        btnConnect = findViewById(R.id.btnConnect)
        orb = findViewById(R.id.orb)
        tvOrbState = findViewById(R.id.tvOrbState)
        tvOrbSub = findViewById(R.id.tvOrbSub)
        tileProfile = findViewById(R.id.tileProfile)
        tvProfileName = findViewById(R.id.tvProfileName)
        tileResolvers = findViewById(R.id.tileResolvers)
        tvResCount = findViewById(R.id.tvResCount)
        btnLog = findViewById(R.id.btnLog)
        tvHint = findViewById(R.id.tvHint)
        btnBackP = findViewById(R.id.btnBackP)
        btnAddP = findViewById(R.id.btnAddP)
        listProfiles = findViewById(R.id.listProfiles)
        etExtra = findViewById(R.id.etExtra)
        btnBackR = findViewById(R.id.btnBackR)
        tvResInfo = findViewById(R.id.tvResInfo)
        btnScan = findViewById(R.id.btnScan)
        btnSaveRes = findViewById(R.id.btnSaveRes)
        btnDefaultRes = findViewById(R.id.btnDefaultRes)
        tvScan = findViewById(R.id.tvScan)
        etResolvers = findViewById(R.id.etResolvers)
    }

    private fun styleViews() {
        Ui.appBg(findViewById<View>(R.id.root))
        Ui.wide(btnLog)
        Ui.wide(btnAddP)
        Ui.wide(btnScan)
        Ui.wide(btnSaveRes)
        Ui.wide(btnDefaultRes)
        Ui.input(etExtra)
        Ui.input(etResolvers)
        Ui.tile(tileProfile, false)
        Ui.tile(tileResolvers, false)
        setChip("قطع", Ui.MUTED)
        tvOrbState.text = "قطع"
        orb.setState(OrbView.OFF)
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this, statusReceiver, IntentFilter(DnsVpnService.ACTION_STATUS),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        applyState(DnsVpnService.state, "")
    }

    override fun onStop() {
        Store.prefs(this).edit().putString("extra", etExtra.text.toString()).apply()
        handler.removeCallbacks(tick)
        unregisterReceiver(statusReceiver)
        super.onStop()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun showTab(i: Int) {
        tab = i
        screens.forEachIndexed { idx, v -> v.visibility = if (idx == i) View.VISIBLE else View.GONE }
        if (i == 0) updateHome()
    }

    private fun leaveTab() {
        if (tab == 2) saveResolverEditor()
        showTab(0)
    }

    private fun setChip(text: String, color: Int) {
        tvChip.text = text
        Ui.pill(tvChip, color)
    }

    // ---------- صفحه‌ی اصلی ----------

    private fun updateHome() {
        val p = Store.active(this)
        tvProfileName.text = p?.let { it.name.ifBlank { it.domain } } ?: "— بساز —"
        tvOrbSub.text = p?.name ?: ""
        val all = Store.readList(Store.allFile(this)).size
        val valid = Store.readList(Store.validFile(this)).size
        tvResCount.text = if (valid > 0) "$valid سالم / $all" else "$all (اسکن نشده)"
        val s = DnsVpnService.state
        if (s == DnsVpnService.STATE_DISCONNECTED) {
            tvHint.text = when {
                p == null -> "اول یک پروفایل سرور (دامنه + کلید) اضافه کن"
                valid == 0 && p.engine != "soar" -> "پیشنهاد: قبل از اتصال «ریزالورها» را اسکن کن"
                else -> "برای اتصال دایره را لمس کن"
            }
        }
    }

    private fun fmtBytes(b: Long): String = when {
        b < 1024L -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    /** ترافیک واقعی روی شبکه (کوئری‌های DNS موتور، چون برنامه از VPN مستثنیه). */
    private fun sampleTraffic() {
        val uid = Process.myUid()
        val rx = TrafficStats.getUidRxBytes(uid)
        val tx = TrafficStats.getUidTxBytes(uid)
        if (rx < 0 || tx < 0) return
        val now = SystemClock.elapsedRealtime()
        if (lastT == 0L) {
            baseRx = rx
            baseTx = tx
            lastRx = rx
            lastTx = tx
            lastT = now
        }
        val dt = (now - lastT).coerceAtLeast(1L)
        val down = (rx - lastRx).coerceAtLeast(0L) * 1000L / dt
        val up = (tx - lastTx).coerceAtLeast(0L) * 1000L / dt
        lastRx = rx
        lastTx = tx
        lastT = now
        tvDown.text = fmtBytes(down) + "/s"
        tvUp.text = fmtBytes(up) + "/s"
        tvTotal.text = fmtBytes((rx - baseRx).coerceAtLeast(0L) + (tx - baseTx).coerceAtLeast(0L))
        orb.setActivity(down + up)
    }

    private fun resetTraffic() {
        tvTimer.text = "00:00:00"
        tvDown.text = "0 B/s"
        tvUp.text = "0 B/s"
        tvTotal.text = "0 B"
        orb.setActivity(0L)
        lastT = 0L
    }

    private fun applyState(state: String, message: String) {
        when (state) {
            DnsVpnService.STATE_CONNECTED -> {
                setChip("متصل", Ui.GREEN)
                tvOrbState.text = "متصل"
                orb.setState(OrbView.ON)
                if (connectedAt == 0L) {
                    connectedAt = System.currentTimeMillis()
                    lastT = 0L
                }
                tvHint.text = "برای قطع، دایره را لمس کن"
                handler.removeCallbacks(tick)
                handler.post(tick)
            }
            DnsVpnService.STATE_CONNECTING -> {
                setChip("در حال اتصال", Ui.AMBER)
                tvOrbState.text = "..."
                orb.setState(OrbView.WAIT)
                handler.removeCallbacks(tick)
                tvHint.text = message.ifBlank { "صبر کن، تست ریزالورها ممکنه چند دقیقه طول بکشه" }
            }
            DnsVpnService.STATE_ERROR -> {
                setChip("خطا", Ui.RED)
                tvOrbState.text = "خطا"
                orb.setState(OrbView.ERR)
                connectedAt = 0L
                handler.removeCallbacks(tick)
                resetTraffic()
                tvHint.text = message
            }
            else -> {
                setChip("قطع", Ui.MUTED)
                tvOrbState.text = "قطع"
                orb.setState(OrbView.OFF)
                connectedAt = 0L
                handler.removeCallbacks(tick)
                resetTraffic()
                updateHome()
            }
        }
    }

    private fun prepareVpn() {
        if (scanning) {
            toast("اسکن در حال انجامه؛ اول تمومش کن یا متوقفش کن")
            return
        }
        if (Store.active(this) == null) {
            toast("اول یک پروفایل سرور اضافه کن")
            renderProfiles()
            showTab(1)
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermissionLauncher.launch(intent) else startVpn()
    }

    private fun startVpn() {
        Store.prefs(this).edit().putString("extra", etExtra.text.toString()).apply()
        val i = Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_START)
        ContextCompat.startForegroundService(this, i)
        applyState(DnsVpnService.STATE_CONNECTING, "")
    }

    private fun stopVpn() {
        startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
    }

    private fun showLog() {
        val t = Logger.tail(80).ifBlank { "لاگی نیست" }
        AlertDialog.Builder(this).setTitle("لاگ موتور").setMessage(t)
            .setPositiveButton("باشه", null)
            .setNeutralButton("کپی") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("log", t))
                toast("کپی شد")
            }
            .show()
    }

    // ---------- پروفایل‌ها ----------

    private fun renderProfiles() {
        listProfiles.removeAllViews()
        val act = Store.active(this)?.id
        val list = Store.profiles(this)
        if (list.isEmpty()) {
            listProfiles.addView(TextView(this).apply {
                text = "هنوز پروفایلی نیست. «+ افزودن» را بزن.\nبدون سرور تونل (دامنه + کلید) هیچ چیزی کار نمیکنه."
                setTextColor(Ui.MUTED)
                setPadding(dp(4), dp(16), dp(4), dp(16))
            })
            return
        }
        for (p in list) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(12), dp(16), dp(12))
            }
            row.addView(TextView(this).apply {
                text = p.name.ifBlank { p.domain }
                setTextColor(Ui.WHITE)
                textSize = 16f
            })
            row.addView(TextView(this).apply {
                text = p.domain + (if (p.engine == "soar") "  • Soar" else "") + (if (p.id == act) "  ✓ فعال" else "")
                setTextColor(if (p.id == act) Ui.GREEN else Ui.MUTED)
                textSize = 12f
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                gravity = Gravity.START
            })
            if (p.id == act) Ui.cardSel(row) else Ui.card(row)
            row.setOnClickListener {
                Store.setActive(this, p.id)
                renderProfiles()
            }
            row.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle("حذف «${p.name}»؟")
                    .setPositiveButton("حذف") { _, _ ->
                        val l = Store.profiles(this)
                        l.removeAll { it.id == p.id }
                        Store.saveProfiles(this, l)
                        renderProfiles()
                    }
                    .setNegativeButton("لغو", null)
                    .show()
                true
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(8)
            listProfiles.addView(row, lp)
        }
    }

    private fun addProfileDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        fun field(hint: String, lines: Int = 1): EditText {
            val e = EditText(this)
            e.hint = hint
            e.layoutDirection = View.LAYOUT_DIRECTION_LTR
            if (lines > 1) {
                e.minLines = lines
                e.gravity = Gravity.TOP or Gravity.START
            } else {
                e.setSingleLine(true)
            }
            box.addView(e)
            return e
        }
        val etPaste = field("لینک soar:// یا stormdns:// یا کل client_config.toml", 3)
        val etName = field("اسم (اختیاری)")
        val etDomain = field("دامنه‌ی سرور تونل، مثلاً t.example.com")
        val etKey = field("کلید رمزنگاری (ENCRYPTION_KEY)")
        val etMethod = field("روش رمزنگاری (عدد؛ پیش‌فرض ۱)")
        AlertDialog.Builder(this)
            .setTitle("پروفایل جدید")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("افزودن") { _, _ ->
                val paste = etPaste.text.toString()
                val name = etName.text.toString().trim()
                val p: Profile? = if (paste.isNotBlank()) {
                    Profile.parse(paste, name)
                } else {
                    val d = etDomain.text.toString().trim()
                    val k = etKey.text.toString().trim()
                    if (d.isEmpty() || k.isEmpty()) null
                    else Profile(Profile.newId(), name.ifBlank { d }, d, k,
                        etMethod.text.toString().trim().toIntOrNull() ?: 1)
                }
                if (p == null) {
                    toast("اطلاعات ناقص یا لینک ناشناخته است")
                } else {
                    val l = Store.profiles(this)
                    l.add(p)
                    Store.saveProfiles(this, l)
                    Store.setActive(this, p.id)
                    renderProfiles()
                }
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    // ---------- ریزالورها و اسکن ----------

    private fun loadResolverEditor() {
        val all = Store.readList(Store.allFile(this))
        val valid = Store.readList(Store.validFile(this))
        etResolvers.setText(all.joinToString("\n"))
        tvResInfo.text = "ریزالورها: ${all.size}" + if (valid.isNotEmpty()) " • سالم: ${valid.size}" else ""
        tvScan.text = if (valid.isNotEmpty()) "اتصال فقط از ریزالورهای سالم استفاده میکنه" else
            "اسکن نشده: اتصال از کل لیست استفاده میکنه (کند شروع میشه)"
    }

    private fun saveResolverEditor() {
        val list = Store.normalize(etResolvers.text.toString())
        if (list.isNotEmpty()) Store.allFile(this).writeText(list.joinToString("\n") + "\n")
    }

    private fun toggleScan() {
        if (scanning) {
            scanEngine?.stop()
            return
        }
        val prof = Store.active(this)
        if (prof == null) {
            toast("اول پروفایل سرور بساز")
            return
        }
        if (prof.engine == "soar") {
            toast("Soar خودش ریزالور پیدا میکند؛ اسکن لازم نیست")
            return
        }
        if (DnsVpnService.state != DnsVpnService.STATE_DISCONNECTED) {
            toast("اول VPN را قطع کن")
            return
        }
        saveResolverEditor()
        val all = Store.readList(Store.allFile(this))
        if (all.isEmpty()) {
            toast("لیست خالیه")
            return
        }
        scanning = true
        btnScan.text = "توقف اسکن"
        val extra = Store.prefs(this).getString("extra", "") ?: ""
        Thread {
            val valid = LinkedHashSet<String>()
            var percent = 0
            try {
                val eng = Engine(this)
                scanEngine = eng
                val resFile = File(eng.dir, "scan_resolvers.txt")
                val cfgFile = File(eng.dir, "scan_config.toml")
                val outFile = File(eng.dir, "scan_output.txt")
                resFile.writeText(all.joinToString("\n") + "\n")
                cfgFile.writeText(Toml.build(prof, DnsVpnService.PORT + 1, "INFO", extra))
                outFile.delete()
                Logger.add("--- اسکن ${all.size} ریزالور ---")
                val p = eng.start(
                    listOf("-config", cfgFile.path, "-resolvers", resFile.path,
                        "-scan-only", "-output", outFile.path)
                ) { line ->
                    Logger.add(line)
                    Regex("WD_SCAN event=valid resolver=(\\S+)").find(line)?.let {
                        synchronized(valid) { valid.add(it.groupValues[1]) }
                    }
                    Regex("percent=(\\d+)").find(line)?.let {
                        percent = it.groupValues[1].toIntOrNull() ?: percent
                    }
                    val n = synchronized(valid) { valid.size }
                    runOnUiThread { tvScan.text = "اسکن: $percent٪ • $n ریزالور سالم" }
                }
                p.waitFor()
                if (outFile.exists()) {
                    synchronized(valid) { valid.addAll(Store.normalize(outFile.readText())) }
                }
            } catch (e: Exception) {
                Logger.add("خطای اسکن: ${e.message}")
            }
            val result = synchronized(valid) { valid.toList() }
            runOnUiThread {
                scanning = false
                scanEngine = null
                btnScan.text = "اسکن ریزالورها"
                if (result.isNotEmpty()) {
                    Store.validFile(this).writeText(result.joinToString("\n") + "\n")
                    toast("${result.size} ریزالور سالم ذخیره شد")
                } else {
                    toast("ریزالور سالمی پیدا نشد (لاگ را ببین)")
                }
                loadResolverEditor()
            }
        }.start()
    }
}
