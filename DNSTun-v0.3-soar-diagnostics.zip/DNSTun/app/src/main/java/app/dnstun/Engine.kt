package app.dnstun

import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit

/** اجرای موتور DNS (libstormdns_client.so که در واقع فایل اجرایی Go هست). */
class Engine(private val ctx: Context, private val binName: String = "libstormdns_client.so") {
    val dir: File = File(ctx.filesDir, "engine").apply { mkdirs() }

    @Volatile
    var process: Process? = null

    fun binary(): File = File(ctx.applicationInfo.nativeLibraryDir, binName)

    fun start(args: List<String>, onLine: (String) -> Unit): Process {
        val bin = binary()
        if (!bin.exists()) throw IllegalStateException("فایل موتور پیدا نشد: ${bin.path}")
        val pb = ProcessBuilder(listOf(bin.path) + args)
            .directory(dir)
            .redirectErrorStream(true)
        pb.environment()["HOME"] = ctx.filesDir.path
        pb.environment()["TMPDIR"] = ctx.cacheDir.path
        val p = pb.start()
        process = p
        Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { onLine(it) }
            } catch (e: Exception) { }
        }.start()
        return p
    }

    fun stop() {
        val p = process ?: return
        process = null
        try {
            p.destroy()
            if (!p.waitFor(1500, TimeUnit.MILLISECONDS)) p.destroyForcibly()
        } catch (e: Exception) { }
    }
}
