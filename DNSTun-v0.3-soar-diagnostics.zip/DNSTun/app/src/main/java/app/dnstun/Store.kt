package app.dnstun

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URI
import java.util.UUID

/** پروفایل سرور: دامنه + کلید رمزنگاری (یا یک client_config.toml کامل). */
data class Profile(
    val id: String,
    var name: String,
    var domain: String,
    var key: String,
    var method: Int = 1,
    var toml: String = "",
    var engine: String = "storm",
    var pubKey: String = "",
    var resolvers: List<String> = emptyList(),
    var soarJson: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("domain", domain)
        .put("key", key).put("method", method).put("toml", toml)
        .put("engine", engine).put("pubKey", pubKey).put("soarJson", soarJson)
        .put("resolvers", JSONArray(resolvers))

    companion object {
        fun newId(): String = UUID.randomUUID().toString().take(8)

        fun fromJson(o: JSONObject): Profile {
            val ra = o.optJSONArray("resolvers")
            val rs = ArrayList<String>()
            if (ra != null) for (i in 0 until ra.length()) rs.add(ra.optString(i))
            return Profile(
                o.getString("id"), o.optString("name"), o.optString("domain"),
                o.optString("key"), o.optInt("method", 1), o.optString("toml"),
                o.optString("engine", "storm"), o.optString("pubKey"), rs, o.optString("soarJson")
            )
        }

        /** soar://<base64url(JSON)> با schema = whitedns.profile (فرمت از یک پروفایل واقعی خونده شد). */
        private fun fromSoar(body0: String, nameHint: String): Profile? {
            var body = body0
            val hash = body.indexOf('#')
            if (hash >= 0) body = body.substring(0, hash)
            val text = tryBase64(body) ?: return null
            return try {
                val root = JSONObject(text)
                val prof = root.getJSONObject("profile")
                val server = prof.getJSONObject("server")
                val dom = server.getString("domain")
                val pk = server.getString("public_key")
                val ra = prof.optJSONArray("resolvers")
                val rs = ArrayList<String>()
                if (ra != null) for (i in 0 until ra.length()) rs.add(ra.optString(i))
                Profile(newId(), nameHint.ifBlank { prof.optString("name", dom) }, dom, "", 1, "",
                    "soar", pk, rs, text)
            } catch (e: Exception) {
                null
            }
        }

        fun loadAll(s: String?): MutableList<Profile> {
            val out = ArrayList<Profile>()
            if (s.isNullOrBlank()) return out
            try {
                val a = JSONArray(s)
                for (i in 0 until a.length()) out.add(fromJson(a.getJSONObject(i)))
            } catch (e: Exception) { }
            return out
        }

        fun saveAll(list: List<Profile>): String {
            val a = JSONArray()
            list.forEach { a.put(it.toJson()) }
            return a.toString()
        }

        /**
         * ورودی میتونه client_config.toml کامل باشه یا لینک stormdns:// / masterdns://.
         * فرمت دقیق لینک‌ها رو نمیدونم؛ چند شکل رایج رو امتحان میکنه.
         */
        fun parse(input: String, nameHint: String): Profile? {
            val t = input.trim()
            if (t.isEmpty()) return null
            if (t.startsWith("soar://", ignoreCase = true)) return fromSoar(t.substring(7), nameHint)
            if (t.contains("DOMAINS") && t.contains("ENCRYPTION_KEY")) return fromToml(t, nameHint)
            val m = Regex("^(stormdns|masterdns)://(.+)$", RegexOption.IGNORE_CASE).find(t) ?: return null
            var body = m.groupValues[2]
            var name = nameHint
            val hash = body.indexOf('#')
            if (hash >= 0) {
                if (name.isBlank()) name = try { java.net.URLDecoder.decode(body.substring(hash + 1), "UTF-8") } catch (e: Exception) { "" }
                body = body.substring(0, hash)
            }
            // ۱) base64 که داخلش TOML یا JSON باشه
            val decoded = tryBase64(body)
            if (decoded != null) {
                if (decoded.contains("DOMAINS") && decoded.contains("ENCRYPTION_KEY")) return fromToml(decoded, name)
                if (decoded.trimStart().startsWith("{")) {
                    try {
                        val j = JSONObject(decoded)
                        val dom = j.optString("domain", j.optString("DOMAIN", j.optString("domains")))
                        val key = j.optString("key", j.optString("encryption_key", j.optString("ENCRYPTION_KEY")))
                        if (dom.isNotBlank() && key.isNotBlank()) {
                            return Profile(newId(), name.ifBlank { dom }, dom, key,
                                j.optInt("method", j.optInt("DATA_ENCRYPTION_METHOD", 1)))
                        }
                    } catch (e: Exception) { }
                }
            }
            // ۲) شکل URI:  key@domain?method=1
            try {
                val u = URI("stormdns://$body")
                val key = u.userInfo
                val host = u.host
                if (!key.isNullOrBlank() && !host.isNullOrBlank()) {
                    val q = (u.query ?: "").split("&").mapNotNull {
                        val kv = it.split("=", limit = 2); if (kv.size == 2) kv[0] to kv[1] else null
                    }.toMap()
                    return Profile(newId(), name.ifBlank { host }, host, key, q["method"]?.toIntOrNull() ?: 1)
                }
                val q = (u.query ?: "").split("&").mapNotNull {
                    val kv = it.split("=", limit = 2); if (kv.size == 2) kv[0] to kv[1] else null
                }.toMap()
                val dom = q["domain"] ?: host
                val k = q["key"]
                if (!dom.isNullOrBlank() && !k.isNullOrBlank()) {
                    return Profile(newId(), name.ifBlank { dom }, dom, k, q["method"]?.toIntOrNull() ?: 1)
                }
            } catch (e: Exception) { }
            return null
        }

        private fun tryBase64(s: String): String? {
            for (flags in intArrayOf(
                Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING,
                Base64.DEFAULT
            )) {
                try {
                    val d = String(Base64.decode(s, flags), Charsets.UTF_8)
                    if (d.isNotBlank() && d.all { it == '\n' || it == '\r' || it == '\t' || it >= ' ' }) return d
                } catch (e: Exception) { }
            }
            return null
        }

        private fun fromToml(toml: String, nameHint: String): Profile? {
            val dom = Regex("DOMAINS\\s*=\\s*\\[\\s*\"([^\"]+)\"").find(toml)?.groupValues?.get(1) ?: return null
            val key = Regex("ENCRYPTION_KEY\\s*=\\s*\"([^\"]*)\"").find(toml)?.groupValues?.get(1) ?: ""
            val method = Regex("DATA_ENCRYPTION_METHOD\\s*=\\s*(\\d+)").find(toml)?.groupValues?.get(1)?.toIntOrNull() ?: 1
            return Profile(newId(), nameHint.ifBlank { dom }, dom, key, method, toml)
        }
    }
}

/** ساخت client_config.toml. */
object Toml {
    private fun q(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    private fun setKey(toml: String, key: String, value: String): String {
        val re = Regex("(?m)^\\s*" + Regex.escape(key) + "\\s*=.*$")
        return if (re.containsMatchIn(toml)) re.replace(toml, Regex.escapeReplacement("$key = $value"))
        else toml.trimEnd() + "\n$key = $value\n"
    }

    fun build(p: Profile, port: Int, logLevel: String, extra: String): String {
        var t = if (p.toml.isNotBlank()) p.toml else
            "DOMAINS = [${q(p.domain)}]\n" +
                "DATA_ENCRYPTION_METHOD = ${p.method}\n" +
                "ENCRYPTION_KEY = ${q(p.key)}\n" +
                "PROTOCOL_TYPE = \"SOCKS5\"\n"
        t = setKey(t, "LISTEN_IP", q("127.0.0.1"))
        t = setKey(t, "LISTEN_PORT", port.toString())
        t = setKey(t, "LOG_LEVEL", q(logLevel))
        t = setKey(t, "LOCAL_DNS_ENABLED", "false")
        // خطوط پیشرفته‌ی کاربر: KEY = VALUE
        for (line in extra.lines()) {
            val m = Regex("^\\s*([A-Z][A-Z0-9_]*)\\s*=\\s*(.+?)\\s*$").find(line) ?: continue
            t = setKey(t, m.groupValues[1], m.groupValues[2])
        }
        return t
    }
}

object Logger {
    private val lines = ArrayDeque<String>()

    @Synchronized
    fun add(s: String) {
        lines.addLast(s)
        while (lines.size > 400) lines.removeFirst()
    }

    @Synchronized
    fun tail(n: Int): String = lines.toList().takeLast(n).joinToString("\n")

    @Synchronized
    fun last(): String = lines.lastOrNull() ?: ""
}

object Store {
    fun prefs(c: Context) = c.getSharedPreferences("dnstun", Context.MODE_PRIVATE)

    fun profiles(c: Context): MutableList<Profile> = Profile.loadAll(prefs(c).getString("profiles", null))

    fun saveProfiles(c: Context, l: List<Profile>) {
        prefs(c).edit().putString("profiles", Profile.saveAll(l)).apply()
    }

    fun setActive(c: Context, id: String) {
        prefs(c).edit().putString("active", id).apply()
    }

    fun active(c: Context): Profile? {
        val l = profiles(c)
        val id = prefs(c).getString("active", "") ?: ""
        return l.firstOrNull { it.id == id } ?: l.firstOrNull()
    }

    fun allFile(c: Context) = File(c.filesDir, "resolvers_all.txt")
    fun validFile(c: Context) = File(c.filesDir, "resolvers_valid.txt")

    fun ensureDefaults(c: Context) {
        val f = allFile(c)
        if (!f.exists()) loadDefaultResolvers(c)
    }

    fun loadDefaultResolvers(c: Context) {
        val text = c.assets.open("default_resolvers.txt").bufferedReader().use { it.readText() }
        allFile(c).writeText(normalize(text).joinToString("\n") + "\n")
    }

    /** یک ریزالور در هر خط؛ ":53" حذف میشه؛ تکراری‌ها و کامنت‌ها دور ریخته میشن. */
    fun normalize(text: String): List<String> {
        val seen = LinkedHashSet<String>()
        for (raw in text.lines()) {
            var l = raw.trim()
            if (l.isEmpty() || l.startsWith("#")) continue
            if (l.endsWith(":53")) l = l.removeSuffix(":53")
            seen.add(l)
        }
        return seen.toList()
    }

    fun readList(f: File): List<String> = if (f.exists()) normalize(f.readText()) else emptyList()
}
