package app.dnstun

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import com.github.shadowsocks.bg.Tun2proxy
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

/**
 * مسیر ترافیک: برنامه‌ها ← TUN ← tun2proxy ← SOCKS5 محلی ← موتور DNS ← ریزالورها ← سرور تونل.
 */
class DnsVpnService : VpnService() {

    companion object {
        const val ACTION_START = "app.dnstun.START"
        const val ACTION_STOP = "app.dnstun.STOP"
        const val ACTION_STATUS = "app.dnstun.STATUS"
        const val EXTRA_STATE = "state"
        const val EXTRA_MESSAGE = "message"
        const val STATE_DISCONNECTED = "disconnected"
        const val STATE_CONNECTING = "connecting"
        const val STATE_CONNECTED = "connected"
        const val STATE_ERROR = "error"
        const val PORT = 18080
        private const val CHANNEL = "dnstun"

        @Volatile
        var state: String = STATE_DISCONNECTED
    }

    private var engine: Engine? = null

    @Volatile
    private var socksPort = PORT

    @Volatile
    private var engineError = ""
    private var tun: ParcelFileDescriptor? = null

    @Volatile
    private var stopping = false

    @Volatile
    private var t2pDone = false

    @Volatile
    private var t2pCode = Int.MIN_VALUE

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (state == STATE_CONNECTING || state == STATE_CONNECTED) return START_NOT_STICKY
                startFg("در حال اتصال...")
                stopping = false
                Thread { connect() }.start()
            }
            ACTION_STOP -> Thread { disconnect() }.start()
        }
        return START_NOT_STICKY
    }

    private fun startFg(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "DNSTun", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("DNSTun")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(1, n)
        }
    }

    private fun publish(s: String, msg: String) {
        state = s
        sendBroadcast(
            Intent(ACTION_STATUS).setPackage(packageName)
                .putExtra(EXTRA_STATE, s).putExtra(EXTRA_MESSAGE, msg)
        )
    }

    private fun portOpen(port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 300) }
        true
    } catch (e: Exception) {
        false
    }

    private fun connect() {
        try {
            publish(STATE_CONNECTING, "آماده‌سازی...")
            Store.ensureDefaults(this)
            val prof = Store.active(this) ?: throw IllegalStateException("اول یک پروفایل سرور بساز")
            val incomplete = if (prof.engine == "soar") {
                prof.domain.isBlank() || prof.pubKey.isBlank()
            } else {
                prof.toml.isBlank() && (prof.domain.isBlank() || prof.key.isBlank())
            }
            if (incomplete) throw IllegalStateException("دامنه و کلید پروفایل کامل نیست")
            val eng = Engine(this, if (prof.engine == "soar") "libsoar_client.so" else "libstormdns_client.so")
            engine = eng
            socksPort = freePort()
            engineError = ""
            val p: Process = if (prof.engine == "soar") launchSoar(prof, eng) else launchStorm(prof, eng)

            // صبر تا پراکسی SOCKS محلی بالا بیاد (تست MTU ریزالورها ممکنه چند دقیقه طول بکشه)
            val deadline = System.currentTimeMillis() + 300_000L
            var ready = false
            while (!stopping && System.currentTimeMillis() < deadline) {
                if (!p.isAlive) throw IllegalStateException("موتور بسته شد: " + engineError.ifBlank { Logger.last() }.take(160))
                if (portOpen(socksPort)) {
                    ready = true
                    break
                }
                publish(STATE_CONNECTING, "تست ریزالورها: " + Logger.last().take(60))
                Thread.sleep(700)
            }
            if (stopping) return
            if (!ready) throw IllegalStateException("موتور تا ۵ دقیقه آماده نشد")

            publish(STATE_CONNECTING, "ساخت تونل...")
            val b = Builder()
                .setSession("DNSTun")
                .setMtu(1400)
                .addAddress("10.255.255.1", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8")
            try {
                // خود برنامه (و موتور DNS) از VPN مستثنی باشن تا کوئری‌ها دور نزنن
                b.addDisallowedApplication(packageName)
            } catch (e: Exception) { }
            val pfd = b.establish() ?: throw IllegalStateException("VPN ساخته نشد (مجوز رد شده؟)")
            tun = pfd

            var t = startTun2proxy(pfd, true)
            Thread.sleep(1500)
            if (t2pDone) {
                Logger.add("tun2proxy کد $t2pCode؛ تلاش دوباره با آرگومان‌های دیگه")
                t = startTun2proxy(pfd, false)
                Thread.sleep(1500)
                if (t2pDone) throw IllegalStateException("tun2proxy اجرا نشد (کد $t2pCode)")
            }
            if (stopping) return
            publish(STATE_CONNECTED, "")
        } catch (e: Exception) {
            if (!stopping) fail(e.message ?: "خطای ناشناخته")
        }
    }

    private fun launchStorm(prof: Profile, eng: Engine): Process {
        val list = Store.readList(Store.validFile(this)).ifEmpty { Store.readList(Store.allFile(this)) }
        if (list.isEmpty()) throw IllegalStateException("لیست ریزالور خالیه")
        val sp = Store.prefs(this)
        val resFile = File(eng.dir, "client_resolvers.txt")
        val cfgFile = File(eng.dir, "client_config.toml")
        resFile.writeText(list.joinToString("\n") + "\n")
        cfgFile.writeText(
            Toml.build(prof, socksPort, sp.getString("log_level", "INFO") ?: "INFO", sp.getString("extra", "") ?: "")
        )
        Logger.add("--- StormDNS با ${list.size} ریزالور ---")
        return eng.start(listOf("-config", cfgFile.path, "-resolvers", resFile.path)) { Logger.add(it) }
    }

    /** هر بار یک پورت آزاد، تا پروسه‌ی یتیمِ اجرای قبلی تداخل نکنه. */
    private fun freePort(): Int = try {
        ServerSocket(0, 0, InetAddress.getByName("127.0.0.1")).use { it.localPort }
    } catch (e: Exception) {
        PORT
    }

    /** خروجی `-h` موتور رو میخونه تا اسم فلگ‌ها رو بدونیم (Go هنگام -h لیست فلگ‌ها رو چاپ میکنه). */
    private fun probeFlags(eng: Engine): Set<String> {
        return try {
            val p = ProcessBuilder(eng.binary().path, "-h").directory(eng.dir).redirectErrorStream(true).start()
            val out = StringBuilder()
            val t = Thread { try { p.inputStream.bufferedReader().forEachLine { out.appendLine(it) } } catch (e: Exception) { } }
            t.start()
            if (!p.waitFor(4, TimeUnit.SECONDS)) p.destroyForcibly()
            t.join(1000)
            val text = out.toString()
            Logger.add("Soar -h:\n" + text.take(1200))
            Regex("(?m)^\\s+-{1,2}([A-Za-z0-9_-]+)").findAll(text).map { it.groupValues[1] }.toSet()
        } catch (e: Exception) {
            Logger.add("probe: ${e.message}")
            emptySet()
        }
    }

    /**
     * Soar: ساختار JSON از تگ‌های باینری خونده شد و «تخت» هست:
     * listen, server_public_key, transport, discovery*, safeQName, maxQName, maxAnswer, holdMs, maxInflight,
     * maxPathWindow, maxStreams, streamWindowKiB, sendBufferKiB, sessionIdleSeconds, dialTimeoutSeconds, country.
     * دامنه و ریزالورها یا فیلد بدون تگ‌اند یا فلگ؛ هر دو حالت رو پوشش میدیم.
     */
    private fun launchSoar(prof: Profile, eng: Engine): Process {
        val resolvers = prof.resolvers.ifEmpty { listOf("1.1.1.1", "8.8.8.8") }
        val res = File(eng.dir, "client_resolvers.txt")
        res.writeText(resolvers.joinToString("\n") + "\n")

        // Fail visibly if the imported share-link is malformed; never silently
        // continue with an empty engine configuration.
        val root = try {
            JSONObject(prof.soarJson)
        } catch (e: Exception) {
            throw IllegalStateException("پروفایل Soar قابل‌خواندن نیست: ${e.message}")
        }
        val profile = root.optJSONObject("profile")
            ?: throw IllegalStateException("پروفایل Soar فاقد بخش profile است")
        val settings = profile.optJSONObject("soarSettings")
            ?: throw IllegalStateException("پروفایل Soar فاقد بخش soarSettings است")
        val server = profile.optJSONObject("server")
            ?: throw IllegalStateException("پروفایل Soar فاقد بخش server است")

        val domain = server.optString("domain", prof.domain).trim()
        val publicKey = server.optString("public_key", prof.pubKey).trim()
        if (domain.isBlank()) throw IllegalStateException("دامنه سرور در پروفایل Soar خالی است")
        if (publicKey.isBlank()) throw IllegalStateException("کلید عمومی سرور در پروفایل Soar خالی است")

        val cfgJson = JSONObject()
        val keys = settings.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            cfgJson.put(key, settings.get(key))
        }
        cfgJson.put("listen", "127.0.0.1:$socksPort")
        cfgJson.put("server_public_key", publicKey)

        val flags = probeFlags(eng)
        if ("config" !in flags) {
            throw IllegalStateException("موتور Soar فلگ -config را اعلام نمی‌کند؛ نسخه موتور با برنامه سازگار نیست")
        }
        val cfg = File(eng.dir, "soar_config.json")
        cfg.writeText(cfgJson.toString())

        // Log only structural metadata. Never log the public key or full config.
        Logger.add("Soar config: ${cfg.length()} bytes; fields=${cfgJson.keys().asSequence().toList().sorted().joinToString(",")}")
        Logger.add("Soar profile: domain=$domain; resolvers=${resolvers.size}; configFlag=true")

        val args = mutableListOf("-config", cfg.path)
        if ("resolvers" in flags) args.addAll(listOf("-resolvers", res.path))
        Logger.add("--- Soar: اجرای موتور با فلگ‌های ${args.filter { it.startsWith("-") }.joinToString(", ")} ---")

        val p = eng.start(args) { line ->
            // The -h probe intentionally prints a help-request error; it is not
            // an engine startup error. Runtime output is captured here.
            Logger.add(line)
            if (line.contains("SOAR_ERROR")) {
                engineError = line.substringAfter("SOAR_ERROR").trim(' ', ':')
            }
            if (line.contains("listen", true)) {
                Regex("127\\.0\\.0\\.1:(\\d{2,5})").find(line)?.let {
                    socksPort = it.groupValues[1].toIntOrNull() ?: socksPort
                }
            }
        }
        Thread.sleep(3000)
        if (p.isAlive) return p
        throw IllegalStateException("Soar پیکربندی JSON را نپذیرفت: ${engineError.ifBlank { Logger.last() }.take(220)}")
    }

    private fun startTun2proxy(pfd: ParcelFileDescriptor, withProgName: Boolean): Thread {
        val base = "--proxy socks5://127.0.0.1:$socksPort --tun-fd ${pfd.fd} --close-fd-on-drop false " +
            "--dns virtual --udp-timeout 10 --tcp-timeout 600 --max-sessions 200 --verbosity info"
        val args = if (withProgName) "tun2proxy $base" else base
        t2pDone = false
        t2pCode = Int.MIN_VALUE
        val t = Thread {
            try {
                t2pCode = Tun2proxy.run(args, 1400.toChar())
            } catch (e: Throwable) {
                Logger.add("tun2proxy: ${e.message}")
                t2pCode = -999
            }
            t2pDone = true
            if (!stopping && state == STATE_CONNECTED) fail("تونل قطع شد (کد $t2pCode)")
        }
        t.start()
        return t
    }

    private fun cleanup() {
        try { Tun2proxy.stop() } catch (e: Throwable) { }
        try { engine?.stop() } catch (e: Exception) { }
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        engine = null
    }

    private fun fail(msg: String) {
        stopping = true
        cleanup()
        publish(STATE_ERROR, msg)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun disconnect() {
        stopping = true
        cleanup()
        publish(STATE_DISCONNECTED, "")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        disconnect()
    }

    override fun onDestroy() {
        if (state == STATE_CONNECTED || state == STATE_CONNECTING) {
            stopping = true
            cleanup()
            publish(STATE_DISCONNECTED, "")
        }
        super.onDestroy()
    }
}
