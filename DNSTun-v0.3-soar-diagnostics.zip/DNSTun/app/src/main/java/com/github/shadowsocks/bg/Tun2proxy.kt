package com.github.shadowsocks.bg

/**
 * اسم کلاس و امضا باید دقیقاً با libtun2proxy.so یکی باشه (JNI):
 * run(String, char): int   و   stop(): int
 */
object Tun2proxy {
    init {
        System.loadLibrary("tun2proxy")
    }

    @JvmStatic
    external fun run(cliArgs: String, tunMtu: Char): Int

    @JvmStatic
    external fun stop(): Int
}
